
// Q1 replace the ????? so that this event listener handles click events on
// the search form 
document.getElementById('?????').addEventListener('click', async() => {

    // Q2 complete this statement to read the timeslot from the form
    const tSlot = ?????; 

    // Q3 complete the fetch API call to send the timeslot
    // to the 'show rooms' route in server.mjs. You will need to look
    // at the server.mjs code to complete this successfully.
    const response = await fetch('?????');
       
    // Q6,8 complete so that it parses the JSON returned and outputs the
    // data to the availableRooms <div> in a readable HTML format, as shown in the paper,
    // and add a "Reserve" button for each message.
    
    // Q17 enhance the above as described in the paper


});

// Q9 replace the ????? so that this event listener handles click events on
// the signup button
// Note the event listener has been setup to be an async function - this may help you
document.getElementById('?????').addEventListener('click', async() => {

    // Q9 complete this statement to read details from the form
    const user = ?????;
    const pass = ?????;
    const cPass = ?????; 
    
       
    // Q9 complete the fetch API call to send the data to the 'signup'
    // route on the server as a POST request within the request body... 


    // Q12 handle non-200 error codes with a message in the 'signupStatus' div...
    
});

// Q13 replace the ????? so that this event listener handles click events on
// the login button
// Note the event listener has been setup to be an async function - this may help you
document.getElementById('?????').addEventListener('click', async() => {

    // Q13 complete code to read user details from the form
   
    // Q13 complete the fetch API call to send the data to the 'login'
    // route on the server as a POST request... 

    // Q14 handle status codes with an appropriate message in the 'loginStatus' div...
});
