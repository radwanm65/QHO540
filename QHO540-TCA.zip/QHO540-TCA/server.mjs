import express from 'express'; 
const app = express();
import Database from 'better-sqlite3';

app.use(express.static('public'));


const db = new Database("t24r.db");
    
// Q4 complete the route to show all rooms available at the given timeslot 
app.get('/showRooms/:timeslot', (req, res) => {
  const stmt = db.prepare("?????");

  // Q5 send back the results as JSON

});


// Q7 complete the route to allow the user to reserve a PC at a given timeslot in a given room
// (defined by ID in the timeslots table)
//
// Q15 add reservation to the pc_bookings table
// Q16 make available only to logged-in users
app.delete('/pc/reserve/:timeslotId', (req, res) => {
  const stmt = db.prepare("?????");
});


// Q10 complete the route to allow the user to signup
// Q11 modify for error-checking as discussed
app.post('/users/signup', (req, res) => {
  const stmt = db.prepare("?????");
});


 
// Q14 complete the login route
app.post('/users/login', (req, res) => {
});

// Q17 add "delete timeslot" route

const PORT = 3000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}.`);
});
